# Databricks notebook source
# MAGIC %md
# MAGIC ## Note:
# MAGIC 
# MAGIC > Variables in **ALL_CAPS** are basic configuration options that the users should check/update for each project

# COMMAND ----------

# MAGIC %sh python --version

# COMMAND ----------

import warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

import pickle, os, hashlib, joblib, datetime
import numpy as np
import pandas as pd
from IPython.display import display

import mlflow
from mlflow.tracking.client import MlflowClient

# COMMAND ----------

# MAGIC %md
# MAGIC ### General Configuration
# MAGIC - `DATA_PATH`: Path to the model development data
# MAGIC     - Should have one target column with values 0 or 1
# MAGIC     - Should have key columns - List of one or more columns comprising a unique key for the data
# MAGIC     - All other column are considered as features for model development
# MAGIC - `KEY_COLS`: List to columns that define a unique key for the data
# MAGIC - `TARGET_COL`: Target columns for model development. Needs to be a binary(only 0, 1) column

# COMMAND ----------

tag="hc_params"
client_name_filter = tag
model_type="post_processing"


# COMMAND ----------

df_train = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/HC_train.csv")
df_test = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/HC_test.csv")


# COMMAND ----------

#['DAYS_BIRTH','CODE_GENDER','DAYS_BIRTH_RAW','CODE_GENDER_RAW']
df_feats = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/HC_feature_imp.csv")
display(df_feats)
#df_feats=df_feats[df_feats.impotance>0.01]
df_feats.columns = ["variable_name","importance"]
print(df_feats.shape)
protected_features = ['DAYS_BIRTH','CODE_GENDER','DAYS_BIRTH_RAW','CODE_GENDER_RAW']

# COMMAND ----------

df_feats[df_feats["variable_name"]=="NAME_FAMILY_STATUS"]

# COMMAND ----------

df_feats.iloc[:,[0]]

# COMMAND ----------


  

# COMMAND ----------

df_train = df_train.reset_index()
df_test = df_test.reset_index()

# COMMAND ----------

KEY_COLS = ['index']
TARGET_COL = 'TARGET'

# COMMAND ----------

trn_columns = list(df_train.columns)
trn_columns.remove(KEY_COLS[0])
trn_columns.remove(TARGET_COL)
protected_features = ['DAYS_BIRTH','CODE_GENDER','DAYS_BIRTH_RAW','CODE_GENDER_RAW']
for i in protected_features:
  trn_columns.remove(i)

# COMMAND ----------

automl_path = '/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/automl_GraphX_%s_%s'%(client_name_filter,model_type)
dbutils.fs.mkdirs(automl_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ### AutoML Configuration
# MAGIC - `automl.set_path(`*`<path>`*`)`: Sets the current woring directory to *`<path>`*. This is the output directory for automl
# MAGIC - `NUM_THREADS`: n; where n = Max number of threads to use for model training. 'n' Can be any integer (Except 0)
# MAGIC     - -1 => Use all possible threads
# MAGIC     - -2 => Use all but one possible threads
# MAGIC     - ..an so on
# MAGIC - `NUM_FOLDS`: Number of folds to use for k-Fold CV
# MAGIC - `RAND_SEED`: Random seed (for reproducibility)

# COMMAND ----------

import automl

# AutoML Configuration
automl.set_path(automl_path)
automl.NUM_THREADS = -1
automl.NUM_FOLDS = 5
automl.RAND_SEED = 123

# COMMAND ----------

# MAGIC %md
# MAGIC ### Experiment Documentation

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql import SQLContext
import pyspark.sql.functions as F
from pyspark.sql.types import *

# COMMAND ----------

#dbutils.fs.mkdirs("/FileStore/AutoML/")

# COMMAND ----------

#ExperimentName='dbfs:/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/' + datetime.datetime.now().isoformat(sep=' ', timespec='milliseconds')
ExperimentName='/Users/c56708a@ascendplatform.experian.com.sg/AutoML/demo_v11202020' + datetime.datetime.now().isoformat(sep=' ', timespec='milliseconds')
ExperimentNote=["## AutoML Experiment"]

experiment = mlflow.create_experiment(ExperimentName)
mlflow.set_experiment(ExperimentName)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Preprocessing

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read Data
# MAGIC `automl.read_data(data_path, key_cols, **kwargs)`<br>
# MAGIC Input:
# MAGIC - data_path: Full path to input file. File can be a .csv or .csv.gz file
# MAGIC - key_cols: List of columns that are used as identifiers. Should make a unique key for the data
# MAGIC - kwargs: Any other keyword arguments that need to be passed to the pandas.read_csv function. NOTE: if parse_dates is not passed, then it is set to True by default
# MAGIC 
# MAGIC Returns:
# MAGIC - Pandas dataframe. Key columns will be dropped from the data and written into 'data_keys.csv' file at the working directory

# COMMAND ----------

#data = automl.read_data(DATA_PATH, KEY_COLS, encoding='utf-8', parse_dates=False)
#print(data.shape)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Split Train-Test
# MAGIC `automl.split_data(data, targ, how='random', train_size = 0.7, random_state=123)`<br><br>
# MAGIC Input:
# MAGIC - data: pandas dataframe
# MAGIC - targ: target column
# MAGIC - how: Default set to 'random'. Currently the only option supported
# MAGIC - train_size: float. Ratio of #records in train data vs input data 
# MAGIC - random_state: Random state for the function - for reproducibility
# MAGIC 
# MAGIC Returns:
# MAGIC - trainX: Pandas DataFrame. All columns except 'targ' for train split
# MAGIC - trainY: Pandas Series. 'targ' column for train split
# MAGIC - testX: Pandas DataFrame. All columns except 'targ' for test split
# MAGIC - testY: Pandas Series. 'targ' column for test split
# MAGIC - folds: Pandas series of same shape as trainY. The values range from 0 to NUM_FOLDS-1 uniformly distributed.

# COMMAND ----------

import random
from random import randint
random.seed(2021)
#trainX = df_train[use_cols]
#trainY = df_train[TARGET_COL]

testX = df_test[trn_columns]
testY = df_test[TARGET_COL]

#folds = [randint(0,automl.NUM_FOLDS-1) for i in range(1,len(trainX)+1) ]
#print(folds)

# COMMAND ----------

trainX, trainY, _, _, folds = automl.split_data(df_train[trn_columns+[TARGET_COL]], TARGET_COL, train_size=0.99, random_state=automl.RAND_SEED)
#trn_idx, tst_idx = trainX.index, testX.index
print("Training data:", trainX.shape, trainY.shape)
print("Test data:", testX.shape, testY.shape)

# COMMAND ----------

type(folds)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Categorical Encoding
# MAGIC 
# MAGIC `automl.CustomLabelEncoder(cat_cols=None, cutoff=5)`<br>
# MAGIC Input:
# MAGIC - cat_cols: List of columns to be treated as categoricals. If None, then inferred during fit.
# MAGIC - cutoff: Can be a int/float/list/dict:
# MAGIC     - int : number of categories to keep per column. The last bin is used as a catch-all. -1 => keep all categories
# MAGIC     - float : Categories with more than cutoff % records in the data kept. Last bin is used as catch-all
# MAGIC     - list : List of cutoff values for each column in cat_cols. Should of the same length and in same order as cat_cols
# MAGIC     - dict : Dict of cutoff values for each column in cat_cols. Should of the same length as cat_cols
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y=None)`: Fits the label encoding schema to the data. Returns self<br>
# MAGIC `.transform(X, y=None)`: Applies the label encoding to the data. Returns pandas dataframe
# MAGIC 
# MAGIC NOTE: If only a subset of columns present in data during transform, then will silently transform the subset - no error or warning raise for the missing columns - since the transformer will be wrapped in future pipeliens with only selected columns

# COMMAND ----------

cat_encoder = automl.CustomLabelEncoder().fit(trainX)
cat_vars = cat_encoder.cat_cols
num_vars = list(set(trainX.columns) - set(cat_vars))
print("Number of numeric variables:", len(num_vars))

# COMMAND ----------

# MAGIC %md
# MAGIC ### IV Based Filter
# MAGIC `automl.IVFilter(max_feats=200, min_iv=-1, novelty=None, max_bins=10, min_bin_size=0.05)`<br><br>
# MAGIC Input:
# MAGIC - max_feats: Maximum number of feature to keep after IV filter
# MAGIC - min_iv: Minimum IV value required to keep a variable after IV filter
# MAGIC - novelty: List of special values (to be treated as separate bins during coarse classing of numeric variables)
# MAGIC - max_bins: Maximum number of bins to create for coarse classing of numeric variables
# MAGIC - min_bin_size: Mimimum fraction of records required in each bin after coarse classing
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y)`: Calculates the IV for all variabels and selects the variables to keep. Returns self<br>
# MAGIC `.transform(X, y=None)`: Applies the IV based feature selection to the data. Returns pandas dataframe
# MAGIC 
# MAGIC NOTE: If only a subset of columns present in data during transform, then will silently transform the subset - no error or warning raise for the missing columns - since the transformer will be wrapped in future pipeliens with only selected columns

# COMMAND ----------

iv_filter = automl.IVFilter(max_feats=200, min_iv=-1, novelty=[np.nan, -np.Inf, np.Inf]).fit(trainX, trainY)
trainX = iv_filter.transform(trainX)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Outlier Treatment
# MAGIC `automl.OutlierTreatment(num_cols=None, low=0.01, high=0.99)`<br><br>
# MAGIC Input:
# MAGIC - num_cols: List of columns to be treated as numeric. If None, then inferred at runtime
# MAGIC - low: lower bound percentile threshold - values below low percentile are set to low percentile
# MAGIC - high: upper bound percentile threshold - values above high percentile are set to high percentile
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y=None)`: Calculates the lower and upper bounds for each column. Returns self<br>
# MAGIC `.transform(X, y=None)`: Applies the lower/upper bounds to the data. Returns pandas dataframe
# MAGIC 
# MAGIC NOTE: If only a subset of columns present in data during transform, then will silently transform the subset - no error or warning raise for the missing columns - since the transformer will be wrapped in future pipeliens with only selected columns

# COMMAND ----------

outlier_limiter = automl.OutlierTreatment(num_vars).fit(trainX)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Drop Cols: Rule Based 
# MAGIC - Constant columns
# MAGIC - Near-Constant columns
# MAGIC - Highly corelated
# MAGIC 
# MAGIC `automl.RuleBasedFeatSel(corr_thresh, const_pct, drop_cols=[])`<br><br>
# MAGIC Input:
# MAGIC - corr_thresh: Correlation threshold. Columns with higher correlation that this with another column are dropped
# MAGIC - const_pct: Constant threshold. Columns with greater than const_pct % records having same value are dropped
# MAGIC - drop_cols: User supplied list of columns to be dropped
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y=None)`: Identifies the columns to be dropped from the data. Returns self<br>
# MAGIC `.transform(X, y=None)`: Drops identified columns. Returns pandas dataframe

# COMMAND ----------

var_drop_rule = automl.RuleBasedFeatSel(0.999, 0.99, []).fit(trainX)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Missing Imputation
# MAGIC 
# MAGIC `automl.NumImputer(num_cols=None, **kwargs)` Wrapper around `sklearn.impute.SimpleImputer` <br><br>
# MAGIC Input:
# MAGIC - num_cols: Numeric columns to be passed to the imputation function. If None, inferred at runtime
# MAGIC - \*\*kwargs: All arguments after 'num_cols' are considered keyword arguments and are passed directly to the `sklearn.impute.SimpleImputer` object. Refer to the sklearn documentation for supported arguments/functionalities
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y=None)`: Fits the imputer instance. Returns self<br>
# MAGIC `.transform(X, y=None)`: Performs imputation on the numeric columns. Returns pandas dataframe
# MAGIC 
# MAGIC NOTE: If only a subset of columns present in data during fit/transform, then will silently fit/transform the subset - no error or warning raise for the missing columns - since the transformer will be wrapped in future pipeliens with only selected columns

# COMMAND ----------

num_imputer = automl.NumImputer(num_vars, strategy="mean", fill_value=None).fit(trainX)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bootstrapped Variable Selection
# MAGIC 
# MAGIC `automl.bootstrap_sel_model`: Model to be usef for bootstrap selection of variables. The default values are:
# MAGIC > model = RandomForestClassifier<br>
# MAGIC > params = {
# MAGIC >     'n_estimators':50, 'max_depth':6,
# MAGIC >     'min_samples_split':30, 'min_samples_leaf':10,
# MAGIC >     'n_jobs':NUM_THREADS, 'random_state':0
# MAGIC > }
# MAGIC 
# MAGIC ___
# MAGIC `automl.BootstrapSelection(model, params, imp_thresh, sample_frac, n_try)`
# MAGIC <br>
# MAGIC 
# MAGIC Input:
# MAGIC - model: model to be usef for bootstrap feature selection 
# MAGIC - params: model hyperparameters to be used
# MAGIC - imp_thresh: Feature importance threshold. Features that have importance above threshold in any iteration of the model are included in selected features
# MAGIC - sample_frac: Percent of input data to be used for each iteration
# MAGIC - n_try: number of iterations
# MAGIC 
# MAGIC Methods:<br>
# MAGIC `.fit(X, y=None)`: Fits the instance - identifies the columns to keep. Returns self<br>
# MAGIC `.transform(X, y=None)`: Returns pandas dataframe with only the selected columns
# MAGIC 
# MAGIC NOTE: If only a subset of columns present in data during transform, then will silently transform the subset - no error or warning raise for the missing columns - since the transformer will be wrapped in future pipeliens with only selected columns

# COMMAND ----------

bootstrap_preprocessor = [cat_encoder, iv_filter, outlier_limiter, var_drop_rule, num_imputer]
bootstrap_preprocessor = automl.make_preprep_pipeline(bootstrap_preprocessor)
model, params = automl.bootstrap_sel_model
var_keep_model = automl.BootstrapSelection(model, params, 0.01, 0.7, 5)
var_keep_model = var_keep_model.fit(bootstrap_preprocessor.transform(trainX), trainY)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Pre-Processing Pipelines
# MAGIC 
# MAGIC `automl.make_preprep_pipeline(steps)`
# MAGIC <br>
# MAGIC 
# MAGIC Input:
# MAGIC - steps: list of transformers
# MAGIC 
# MAGIC Returns: sklearn.pipeline obejct

# COMMAND ----------

preprocessor1 = [cat_encoder, iv_filter, outlier_limiter, var_drop_rule, var_keep_model]
preprocessor2 = [cat_encoder, iv_filter, outlier_limiter, var_drop_rule, num_imputer, var_keep_model]

preprocessor1 = automl.make_preprep_pipeline(preprocessor1)
preprocessor2 = automl.make_preprep_pipeline(preprocessor2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Modeling 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Hyper-parameter Turning
# MAGIC **Random Search + Bayesian Optimization**

# COMMAND ----------

# MAGIC %md
# MAGIC #### Search Setup
# MAGIC - `SEL_FEATS`: Flag to perform feature selection during hyper-parameter tuning
# MAGIC - `N_RANDOM`: Number of randomized iterations before Bayesian Optimization starts
# MAGIC - `N_TOTAL`: Total number of iterations for hyper-parameter tuning (Number of bayesian iterations = N_TOTAL - N_RANDOM)
# MAGIC - `MODEL_LIST`: List of models to tune (each element in this list must be present as a key in automl.tuning_grid dict)
# MAGIC - `preprocessors`: Dictionary of preprocessors for each model type - must be sklearn.pipeline objects

# COMMAND ----------

SEL_FEATS = True
N_RANDOM = 20
N_TOTAL = 40
optimizer = {}
tracker = {}

MODEL_LIST = [ 'XGB','LGBM','RF']
preprocessors = {'XGB':preprocessor1, 'RF':preprocessor2, 'LGBM':preprocessor1}

# COMMAND ----------

# MAGIC %md
# MAGIC #### Hyper-Parameter Grid
# MAGIC `automl.tuning_grid`: Dicionary of specs for each model (XGB/RF/LGBM). The value corresponding to each key is a list with the following elements:
# MAGIC - Model Function ('sklearn.ensemble.RandomForestClassifier' in the example below)
# MAGIC - Dictionary of model hyperparameter mapped to their bounds for optimization. The keys of this dictionary are the hyperparameter names and values are tuples corresponding to the lower and upper bound for optimization
# MAGIC - Dictionary of fixed hyperparameters (mapped to their values) for model. 
# MAGIC - Dictionary of hyperparameter validation functions: Keys are hyperparameter names, values are functions to apply to the hyperparameter value before passing to the model (this is required since the optimization package treats all variables as floats, but the model classess need some hyperparameters to be int)
# MAGIC <br>Example: <br>
# MAGIC > `automl.tuning_grid["RF"]` = [<br>
# MAGIC >     sklearn.ensemble.RandomForestClassifier,    # Model Function
# MAGIC >     {   # Optimization Hyperparameter Bounds
# MAGIC >         'n_estimators': (50, 500),
# MAGIC >         'max_depth' : (3, 7),
# MAGIC >         'min_samples_split' : (20, 500),
# MAGIC >         'min_samples_leaf' : (5, 200),
# MAGIC >         'max_features' : (0.01, 1)
# MAGIC >     },
# MAGIC >     {   # Fixed Hyperparameters
# MAGIC >         'random_state':RAND_SEED, 
# MAGIC >         'n_jobs':NUM_THREADS
# MAGIC >     },
# MAGIC >     {   # Validation Functions
# MAGIC >         'n_estimators' : automl.to_int,        # Convert to integer from float
# MAGIC >         'max_depth' : automl.to_int,           # Convert to integer from float
# MAGIC >         'min_samples_split' : automl.to_int,   # Convert to integer from float
# MAGIC >         'min_samples_leaf' : automl.to_int,    # Convert to integer from float
# MAGIC >     }
# MAGIC > ]

# COMMAND ----------

#automl.tuning_grid["LGBM"][1]["num_leaves"]=(20,50)
#automl.tuning_grid["LGBM"][1]

# COMMAND ----------

automl.tuning_grid = automl.getTuningGrid()
automl.tuning_grid["LGBM"][1]["num_leaves"]=(20,100)
automl.tuning_grid["LGBM"][1]["min_data_in_leaf"]=(5,200)
#automl.tuning_grid["LGBM"][1]["min_data_in_leaf"]=(9,30)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Model Tuning
# MAGIC 
# MAGIC `automl.BayesianOpt(n_random, param_optim, param_const, validation_func, random_state=123)`: A class to maintain the bayesian optimization states and fetch new parameter suggestions
# MAGIC <br>
# MAGIC Input:
# MAGIC - n_random: Number of iterations for random grid search before switching to bayesian optimization
# MAGIC - param_optim: Dictionary of hyperparameters (mapped to their bounds) to optimize
# MAGIC - param_const: Dictionary of fixed hyperparameters
# MAGIC - validation_func: Dictionary of hyperparameters mapped to validation functions
# MAGIC - random_state: Random state for the function - for reproducibility
# MAGIC 
# MAGIC Methods:<br>
# MAGIC *All the below methods are only used internally by the automl.TuneParameters function - users need not familiarize themselves with these methods to use the automl tool*<br>
# MAGIC `.get_next_point()`: Returns the next hyperparameters to try (random of #tries < n_random, else suggested optimum)<br>
# MAGIC `.update_utility(perf, params)`: Updates the utility function with the performance (perf) of the a set of parameters (params)<br>
# MAGIC `.update_search_params(**kwargs)`: Updates the parameter bounds for hyperparameters to optimize<br>
# MAGIC `.update_validation_func(**kwargs)`: Updates the validation function for hyperparameters<br>
# MAGIC `.update_const_params(**kwargs)`: Updates the constant hyperparameters
# MAGIC 
# MAGIC ___
# MAGIC 
# MAGIC `automl.TrackModels(model, model_name)`: A class to track the model parameters tried, performance, etc. during parameter optimization
# MAGIC <br>
# MAGIC Input:
# MAGIC - model: Model function
# MAGIC - model_name: str. Name of the model<br>
# MAGIC 
# MAGIC Attributes:
# MAGIC - perfdf: A dataframe of performance of all models tried. Columns: ['Index', 'Trn_AUC', 'Kf_AUC', 'Val_AUC', 'n_feats', 'Runtime']
# MAGIC - preds: A dataframe of (k-fold) predicitons on training data for each model tried (Columns are named as `<model_name>_<index>`)
# MAGIC - feat_imp: A dataframe of feature importances for each model tried - missing values are imputed with zeros
# MAGIC - self.best_model: Index and parameters for the best model identified (selected using a heuristic on the tradeoff between perfromance and overfitting). Only updated after `.update_best_model()` function is called.
# MAGIC - self.best_model_perf: Train, k-fold average and k-fold stacked AUC corresponding to the best model
# MAGIC 
# MAGIC Methods:<br>
# MAGIC *The below methods are used internally by the automl.TuneParameters function - users need not familiarize with these*<br>
# MAGIC `.update_best_model(thresh)`: Updates the best_model attributes - overfitting (train-validation AUC) is discretized in bins of thresh and the model with highest validation AUC in the best bin is selected<br>
# MAGIC `.register(n, param, feat_imp, trn, kf, val, preds, runtime)`: Register a single iteration
# MAGIC > `n`: Index<br>
# MAGIC > `param`: model parameters<br>
# MAGIC > `feat_imp`: pandas dataframe with feature importances for k-fold as well as overall model<br>
# MAGIC > `trn, kf, val`: AUC for training, avg. k-fold and stacked k-fold respectively<br>
# MAGIC > `preds`: prediction on training data (k-fold oos predictions)<br>
# MAGIC > `runtime`: runtime for the iteration
# MAGIC 
# MAGIC ___
# MAGIC 
# MAGIC `automl.TuneParameters(X, y, folds, model, n_total, optimizer, model_tracker, 
# MAGIC                        sel_feats=True, thresh = 0.025, penalize_overfitting=False)`: Function to tune the hyper-parameters
# MAGIC <br>
# MAGIC <br>
# MAGIC Input:
# MAGIC - X, y: Input data - pandas dataframe/series<br>
# MAGIC - folds: Pandas series identifying the folds for each record<br>
# MAGIC - model: model function<br>
# MAGIC - n_total: total iterations to try (for parameter optimization)<br>
# MAGIC - optimizer: Instance of optimizer class to handle bayesian optimization (n_random defined while initializing this)<br>
# MAGIC - model_tracker: Instance of tracker class to track model perf, pred, feat_imp, etc. for each iteration<br>
# MAGIC - sel_feats: If set to True, then for each iteration (i.e. each sample hyper-parameter combination to evaluate), the model is trained recursively after dropping features with zero importance untill all features remaining are important. Takes longer to run.
# MAGIC - thresh: Overfitting threshlold. If train_auc - out_of_sample_auc > thresh, then model considered overfit
# MAGIC - penalize_overfitting: If set to true, then the utility for optimization (oos auc) is penalized by ```x/2^(10x)``` where ```x = trn_auc - oos_auc - thresh``` for all x > 0
# MAGIC <br>
# MAGIC 
# MAGIC Returns:
# MAGIC - tracker: Updated tracker instance with the perf details of the tuning iterations
# MAGIC - optimizer: Optimizer instance with the optimized utility function

# COMMAND ----------

for mdl in MODEL_LIST:
    print("=="*10, mdl, "=="*10)
    print("Training Data:", preprocessors[mdl].transform(trainX).shape)
    np.random.seed(automl.RAND_SEED)
    
    model_func, param_optim, param_const, validation_func = automl.tuning_grid[mdl]
    
    optimizer[mdl] = automl.BayesianOpt(N_RANDOM, param_optim, param_const, validation_func, random_state=automl.RAND_SEED)
    tracker[mdl] = automl.TrackModels(model_func, mdl)
    
    tracker[mdl], optimizer[mdl] = automl.TuneParameters(preprocessors[mdl].transform(trainX), trainY, folds, model_func,
                                                         N_TOTAL, optimizer[mdl], tracker[mdl], SEL_FEATS,
                                                         thresh=0.025, penalize_overfitting=True)

    #with open(f'{mdl}/{mdl}_parameter_tuning.pickle', 'wb') as fp: pickle.dump([tracker[mdl], optimizer[mdl]], fp)

#with open('parameter_tuning.pickle', 'wb') as fp: pickle.dump([tracker, optimizer], fp)

# COMMAND ----------

preprocessors[mdl].transform(trainX)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ensemble
# MAGIC 
# MAGIC Given a overfitting threshold (```thresh```); from each model family **Select Models** using the below logic:
# MAGIC >- Select top 2 models (Highest k-fold OOS AUC) each with
# MAGIC >    - overfitting upto thresh%
# MAGIC >    - overfitting between thresh to 2\*thresh%
# MAGIC >- Select 2 additional model with highest k-fold OOS AUC
# MAGIC >- Select 2 additional model with highest k-fold OOS AUC satisfying:
# MAGIC >    - Lowest average corelation with above selected models, and
# MAGIC >    - Overfitting < 2\*thresh%
# MAGIC >- Select 2 additional model with highest k-fold OOS AUC satisfying:
# MAGIC >    - Lowest average corelation with above selected models, and
# MAGIC >    - Overfitting < 4\*thresh%

# COMMAND ----------

# MAGIC %md
# MAGIC `automl.get_selected_models(tracker, model_list, kf_models=False, thresh=0.025, pre_sel_models=None)`: Selects models based on the above heuristic
# MAGIC <br>
# MAGIC Inputs:
# MAGIC - tracker: dictionary of tracker objects
# MAGIC - model_list: list of model names (keys of tracker argument)
# MAGIC - kf_models: Flag. If set to True, then the function returns model objects for all 'k' folds. Else just one model object trained on the overall training data is returned
# MAGIC - thresh: overfitting threshold. Used in the heuristic for selecting models for ensemble
# MAGIC - pre_sel_models: Pre-Selected models. A dictionary with MODEL_LIST as keys and Model_IDs as values. If pre_set_models is supplied, then only the model_ids supplied will be selected and no heuristic will be used for selecting base models for ensemble. Eg. usage:
# MAGIC 
# MAGIC >`pre_sel_models = {'XGB':['XGB_1','XGB_5']}` (only model_ids 1 and 5 from the XGB iterations will be used for ensemble)
# MAGIC 
# MAGIC Returns:
# MAGIC - mdl_ids: Dictionary of model_name -> list of selected model IDs
# MAGIC - mdl_objs: Dictionary of model_name -> list of (list of model objects for overall and each fold) for each model_id
# MAGIC - mdl_cols: Dictionary of model_name -> list of (list of selected features for model_id) for each model_id

# COMMAND ----------

KF_MODELS = False

mdl_ids, mdl_objs, mdl_cols = automl.get_selected_models(tracker, MODEL_LIST, KF_MODELS, 0.025, None)

preds = pd.concat([tracker[m].preds for m in MODEL_LIST], axis=1)
#sel_models = sum(mdl_ids.values(), [])
#Try differene top model combinations
import itertools
a =list(mdl_ids.values())
sel_models =list(itertools.chain.from_iterable(a))
print(sel_models)

ensembleX = preds[sel_models]

# COMMAND ----------

mdl_ids.values()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Tune Ensemble

# COMMAND ----------

mdl = 'ENSEMBLE'

np.random.seed(automl.RAND_SEED)

model_func, param_optim, param_const, validation_func = automl.tuning_grid[mdl]

optimizer[mdl] = automl.BayesianOpt(N_RANDOM, param_optim, param_const, validation_func, random_state=automl.RAND_SEED)
tracker[mdl] = automl.TrackModels(model_func, mdl)

tracker[mdl], optimizer[mdl] = automl.TuneParameters(ensembleX, trainY, folds, model_func, 
                                                     N_TOTAL, optimizer[mdl], tracker[mdl], SEL_FEATS,
                                                     thresh=0.025, penalize_overfitting=True)

with open(f'{mdl}/{mdl}_parameter_tuning.pickle', 'wb') as fp: pickle.dump([tracker[mdl], optimizer[mdl]], fp)
with open('parameter_tuning.pickle', 'wb') as fp: pickle.dump([tracker, optimizer], fp)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Final Ensemble

# COMMAND ----------

ensemble_id, ensemble_param = tracker['ENSEMBLE'].best_model

row = tracker['ENSEMBLE'].perfdf
row = row[row['Index'] == ensemble_id]
ensemble_feats = row['Features'].values.tolist()[0]
ensemble_feats = eval(ensemble_feats)
ensemble_param = eval(ensemble_param)
ensemble_model = model_func(**ensemble_param)
ensemble_model = ensemble_model.fit(ensembleX[ensemble_feats], trainY)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Pipeline
# MAGIC 
# MAGIC `automl.make_model_pipelines(preprep, model_objs, model_cols, kf_models=False)`: Function to create pipelines for model predictions. The pipelines will take raw data as input and return final model prediction (handling averaging of k-fold predictions internally)<br>
# MAGIC Inputs:
# MAGIC - preprep: List of preprocessing transformers (common for all model_ids)
# MAGIC - model_objs: list of (list of model objects for overall and each fold) for each model_id
# MAGIC - model_cols: list of (list of selected features for model_id) for each model_id
# MAGIC - kf_models: Flag. If set to True, then the final prediction is an average of the predicitons on all folds' models. If Flase, then the prediction is the prediciton from the overall model
# MAGIC 
# MAGIC Returns:
# MAGIC - list of pipeline objects for each model_id. Each pipeline object is an end to end pipeline version of the model 'model_id' handling all preprocessing, post_processing internally
# MAGIC 
# MAGIC ___
# MAGIC 
# MAGIC `automl.make_ensemble_pipeline(ensemble_model, ensemble_feats, preprocessors, model_objs, model_cols, kf_models=False)`: Function to create pipelines for ensemble prediction. The pipeline will take raw data as input and return final model prediction (handling ensemble of pipelines/models internally)<br>
# MAGIC Inputs:
# MAGIC - ensemble_model: Final (trained) ensemble model object
# MAGIC - ensemble_feats: Input column names for the ensemble model (column name for model predictions for each base predictor)
# MAGIC - preprocessors: Dictionary of preprocessor pipelines for each model type in MODEL_LIST
# MAGIC - model_objs: Dictionary of (list of (list of model objects for overall and each fold) for each model_id) for each model type in MODEL_LIST
# MAGIC - model_cols: Dictionary of (list of (list of selected features for model_id) for each model_id) for each each model type in MODEL_LIST
# MAGIC - kf_models: Flag. If set to True, then the final prediction for base models is an average of the predicitons on all folds' models. If Flase, then the prediction is the prediciton from the overall model
# MAGIC 
# MAGIC 
# MAGIC Returns:
# MAGIC - Final ensemble pipeline which takes raw data as input and return the final prediction as output (from predict_proba)

# COMMAND ----------

pipelines = {}

for mdl in MODEL_LIST:
    pipelines[mdl] = automl.make_model_pipelines(preprocessors[mdl], mdl_objs[mdl], mdl_cols[mdl], KF_MODELS)

pipelines['ENSEMBLE'] = automl.make_ensemble_pipeline(ensemble_model, ensemble_feats, preprocessors, mdl_ids, mdl_objs, mdl_cols, KF_MODELS)

with open('pipelines.pickle', 'wb') as fp: pickle.dump(pipelines, fp)
#with open('DATA/trn_tst_fold_index.pickle', 'wb') as fp: pickle.dump([trn_idx, tst_idx, folds], fp)
with open('ENSEMBLE/ensemble_items.pickle', 'wb') as fp: pickle.dump([ensemble_model, ensembleX, ensemble_feats], fp)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reports

# COMMAND ----------

with open('pipelines.pickle', 'rb') as fp: pipelines = pickle.load(fp)
#with open('DATA/trn_tst_fold_index.pickle', 'rb') as fp: trn_idx, tst_idx, folds = pickle.load(fp)
with open('ENSEMBLE/ensemble_items.pickle', 'rb') as fp: ensemble_model, ensembleX, ensemble_feats = pickle.load(fp)

  


# COMMAND ----------

Xtrn = trainX#data.loc[trn_idx].drop(TARGET_COL, axis=1)
Xtst = testX#data.loc[tst_idx].drop(TARGET_COL, axis=1)
ytrn = trainY#data.loc[trn_idx][TARGET_COL]
ytst = testY#data.loc[tst_idx][TARGET_COL]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Select Model/Data for Reports

# COMMAND ----------

SELECTED_MODEL = 'ENSEMBLE' #ENSEMBLE/XGB/RF/LGBM

if SELECTED_MODEL == 'ENSEMBLE':
    final_model = pipelines[SELECTED_MODEL]
    yhtrn = ensemble_model.predict_proba(ensembleX[ensemble_feats])[:,1]
else:
    final_model = pipelines[SELECTED_MODEL][0]
    yhtrn = final_model.predict_proba(Xtrn)[:,1]

#yhtrn = pd.Series(yhtrn, index=trn_idx)

yhtst = final_model.predict_proba(Xtst)[:,1]
yhtst = pd.Series(yhtst)

yfull = pd.concat([ytrn, ytst])
#yhfull = pd.concat([yhtrn, yhtst])

# COMMAND ----------

pipelines['XGB'][0][1][1]

# COMMAND ----------

#clos  = final_model.steps[0][1].colnames
#print('The column select for model:' , clos)
 
transformers  = final_model.steps[1][1].transformer_list[0][1].kw_args['mdl']

# COMMAND ----------

final_model

# COMMAND ----------

# MAGIC %md
# MAGIC ### Model Perf: GINI, ROC
# MAGIC `automl.model_auc(y, yh, title)`
# MAGIC Inputs:
# MAGIC - y: Actuals
# MAGIC - yh: Predicted probabilities
# MAGIC - title: Title for the chart
# MAGIC 
# MAGIC Returns:
# MAGIC - Dataframe with 'title' as the index. Columns are #Records, #Targets, TargRate, auc, ks, gini
# MAGIC - AUC Chart (matplotlib figure object)

# COMMAND ----------

# MAGIC %md
# MAGIC `automl.model_auc(y, yh, title)`
# MAGIC Inputs:
# MAGIC - y: Actuals
# MAGIC - yh: Predicted probabilities
# MAGIC - title: Title for the chart
# MAGIC 
# MAGIC Returns:
# MAGIC - Dataframe with 'title' as the index. Columns are #Records, #Targets, TargRate, auc, ks, gini
# MAGIC - AUC Chart (matplotlib figure object)

# COMMAND ----------

perf_trn, fig_auc_trn = automl.model_auc(ytrn, yhtrn, "Train")
perf_tst, fig_auc_tst = automl.model_auc(ytst, yhtst, "Test")
#perf_full, fig_auc_full = automl.model_auc(yfull, yhfull, "Overall")

summary = pd.concat([perf_trn, perf_tst])
print(summary)
display(fig_auc_tst)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Feature Importance
# MAGIC 
# MAGIC `automl.get_feat_imp(model)`
# MAGIC Inputs:
# MAGIC - model: model under consideration
# MAGIC     
# MAGIC Returns:
# MAGIC - Dataframe with two columns: ['Feature', 'Importance']

# COMMAND ----------

feat_imp = automl.get_feat_imp(final_model)
print(feat_imp)

# COMMAND ----------

feat_imp

# COMMAND ----------

# MAGIC %md
# MAGIC ### Explain Prediction
# MAGIC 
# MAGIC `automl.get_explainer(model, X)`
# MAGIC Input:
# MAGIC - model: Model under consideration
# MAGIC - X: Original training data
# MAGIC 
# MAGIC Returns:
# MAGIC - An explainer object (shap explainer). Would be used for downstream explainability functions
# MAGIC ___
# MAGIC `automl.explain_prediction(explainer, row)`
# MAGIC Input:
# MAGIC - explainer: explainer object from automl.get_explainer() function
# MAGIC - row: Record to be explained - pandas dataframe (with 1 row) or pandas series
# MAGIC 
# MAGIC Returns:
# MAGIC - shap values for each feature in the row
# MAGIC - base shap values (model level average)
# MAGIC - shap force plot (matplotlib figure object)

# COMMAND ----------

#explainer = automl.get_explainer(final_model, Xtrn)
#shap_values, base_values, plot = automl.explain_prediction(explainer, Xtrn.iloc[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Compare Prediction
# MAGIC 
# MAGIC `automl.compare_prediction(explainer, row1, row2)`: Compare the predictions of two records
# MAGIC Input:
# MAGIC - explainer: explainer object from automl.get_explainer() function
# MAGIC - row1: Reference record 
# MAGIC - row2: Record to be compared with the reference record
# MAGIC 
# MAGIC Returns:
# MAGIC - pandas dataframe for the comparision. Positive value in the column 'ShapDiff' indicates that the feature is increasing the value of (score_row2 - score_row1) and vice versa

# COMMAND ----------

#comparison = automl.compare_prediction(explainer, Xtrn.iloc[0], Xtrn.iloc[100])
#comparison[comparison.AbsDiff > 0].head()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Partial Dependence Plots
# MAGIC 
# MAGIC To Do:
# MAGIC     1. For ensemble, plot the charts in a grid instead of one column
# MAGIC     2. Functionality to plot the pdp for base predictions
# MAGIC 
# MAGIC `automl.plot_pdp(model, X, feature)`: Plots pdp charts for all predictors (base predictors) in the model object
# MAGIC Input:
# MAGIC - model: model under consideration
# MAGIC - X: training data
# MAGIC - feature: feature for which the pdp plots need to be created
# MAGIC 
# MAGIC Returns:
# MAGIC - None

# COMMAND ----------

#automl.plot_pdp(final_model, Xtrn, 'TENURE')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Score Calibration
# MAGIC 
# MAGIC `automl.score_calibration(y, yh, yh_tst=None, bad=1, pdo=20, base=600, base_odds=20, num_bins=10)`
# MAGIC Input:
# MAGIC - y, yh: Training Actuals and predicted
# MAGIC - yh_tst: Predictions on test
# MAGIC - bad: Value for bads in 'y', bad=1 => the model is developed for identifying bads (1 in the target column is for bads)
# MAGIC - pdo: points to double odds
# MAGIC - base: base score for calibration corresponding to the base odds
# MAGIC - base_odds: value of odds for base score
# MAGIC - num_bins: number of bins to use for calibration
# MAGIC 
# MAGIC Returns:
# MAGIC - intercept
# MAGIC - slope
# MAGIC - calibration_report: summary of good/bads/odds/scores for each bin
# MAGIC - scaled train predictions (= slope\*log_GBOdds_trn + intercept)
# MAGIC - scaled test predictions (= slope\*log_GBOdds_tst + intercept)

# COMMAND ----------

intercept, slope, calibration_report, yhtrn_scaled, yhtst_scaled = automl.score_calibration(ytrn, yhtrn, yhtst, bad=1, pdo=20, base=600, base_odds=20, num_bins=10)
print(intercept, slope)
calibration_report

# COMMAND ----------

# MAGIC %md
# MAGIC ### Decile Report
# MAGIC 
# MAGIC `automl.score_decile_report(y, yh, bad=1, dataset_type='Train', bins=10)`
# MAGIC Inputs:
# MAGIC - y, yh: actuals and predicted
# MAGIC - bad: Value for bads in 'y', bad=1 => the model is developed for identifying bads (1 in the target column is for bads)
# MAGIC - dataset_type: title for charts
# MAGIC - bins: Can be int, or pd.Series. If int, then bins = number of bins for the report (equal volume bins). If series, then the series values are used as the cutoffs for deciding the bins. Series should be of the same format as the 'ScoreRange' column from the output of this function
# MAGIC 
# MAGIC Returns:
# MAGIC - Pandas dataframe with the decile report - similar to score calibration reports with few additional columns, most notably the 'ScoreRange' column which has the following format for each bin:
# MAGIC     - First bin: (-, \< upper bound >]
# MAGIC     - Last bin: \[\< lower bound >, -)
# MAGIC     - Other bins: \[\< lower bound >, \< upper bound >)
# MAGIC - figure object for decile wise event rate (line chart) and record count(hist chart)
# MAGIC - figure object for the KS Chart

# COMMAND ----------

report_trn, fig_decile_trn, fig_ks_trn = automl.score_decile_report(ytrn, yhtrn_scaled, 1, 'Train', 10)
display(fig_decile_trn, fig_ks_trn)
report_trn

# COMMAND ----------

report_tst, fig_decile_tst, fig_ks_tst = automl.score_decile_report(ytst, yhtst_scaled, 1, 'Test', report_trn['ScoreRange'])
display(fig_decile_tst, fig_ks_tst)
report_tst

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write Report to Excel

# COMMAND ----------

automl.write_report(
    summary = summary,
    auc_figs = [fig_auc_trn, fig_auc_tst, fig_auc_full],
    feat_imp = feat_imp,
    calibration_report = calibration_report,
    decile_report_trn = [report_trn, fig_decile_trn, fig_ks_trn],
    decile_report_tst = [report_tst, fig_decile_tst, fig_ks_tst],
    outfile = '/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/automl_demo_v11202020/Report.xlsx'
)

# COMMAND ----------

preds = automl.write_predictions(yhtrn, yhtst, folds, ytrn, ytst)

# COMMAND ----------

