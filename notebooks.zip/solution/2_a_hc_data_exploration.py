# Databricks notebook source
# MAGIC %md
# MAGIC <h2>Model development Notebook - Veritas</h2>
# MAGIC 
# MAGIC 
# MAGIC <ol>
# MAGIC <li>CC lead prediction</li>
# MAGIC <li>Banking lead prediction </li>
# MAGIC <li>German credit risk</li>
# MAGIC <li>HC default risk</li>
# MAGIC <li>Synthetic loan data</li>
# MAGIC </ol>

# COMMAND ----------

# MAGIC %md
# MAGIC <h3>Import packages</h3>

# COMMAND ----------

from sklearn.metrics import accuracy_score,roc_auc_score,confusion_matrix
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.preprocessing import LabelEncoder
from scipy.stats import chi2_contingency
from scipy.stats import pointbiserialr
import matplotlib.pyplot as plt
from sklearn.svm import SVC
import xgboost as xgb
import seaborn as sns
import pandas as pd
import numpy as np

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>Function definition</h5>

# COMMAND ----------

train = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/hc_default_risk.csv")
bureau = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/bureau.csv")

# COMMAND ----------

display(train)

# COMMAND ----------

train.shape

# COMMAND ----------


display(bureau)

# COMMAND ----------

print(bureau.shape)
bureau.drop_duplicates("SK_ID_CURR",keep="last",inplace=True)
bureau["bureau_presence"]=1
print(bureau.shape)
#display(bureau)

# COMMAND ----------

print(train.shape)
temp = train.merge(bureau[["SK_ID_CURR","bureau_presence"]],on="SK_ID_CURR",how="left")
train = temp[temp.bureau_presence!=1]
print(train.shape)


# COMMAND ----------

train.info()

# COMMAND ----------

train.describe(include='all')

# COMMAND ----------

train.isna().sum()

# COMMAND ----------

#NAME_EDUCATION_TYPE,NAME_FAMILY_STATUS

# COMMAND ----------

drop_list = ['FLAG_DOCUMENT_2','FLAG_DOCUMENT_4','FLAG_DOCUMENT_5','FLAG_DOCUMENT_7','FLAG_DOCUMENT_9','FLAG_DOCUMENT_10',
            'FLAG_DOCUMENT_11','FLAG_DOCUMENT_12','FLAG_DOCUMENT_13','FLAG_DOCUMENT_14','FLAG_DOCUMENT_15','FLAG_DOCUMENT_17',
            'FLAG_DOCUMENT_19','FLAG_DOCUMENT_20','FLAG_DOCUMENT_21','AMT_REQ_CREDIT_BUREAU_HOUR','AMT_REQ_CREDIT_BUREAU_DAY','AMT_REQ_CREDIT_BUREAU_WEEK',
             'AMT_REQ_CREDIT_BUREAU_MON','AMT_REQ_CREDIT_BUREAU_QRT','AMT_REQ_CREDIT_BUREAU_YEAR','bureau_presence','WEEKDAY_APPR_PROCESS_START','HOUR_APPR_PROCESS_START']

cat_features = ['NAME_CONTRACT_TYPE','CODE_GENDER','FLAG_OWN_CAR','FLAG_OWN_REALTY','CNT_CHILDREN','NAME_TYPE_SUITE',
               'NAME_INCOME_TYPE','NAME_HOUSING_TYPE','OCCUPATION_TYPE','ORGANIZATION_TYPE','FONDKAPREMONT_MODE','HOUSETYPE_MODE',
               'WALLSMATERIAL_MODE','EMERGENCYSTATE_MODE','NAME_EDUCATION_TYPE','NAME_FAMILY_STATUS']

ID = ["SK_ID_CURR"]
TARGET  = ["TARGET"]


# COMMAND ----------

train.drop(drop_list, axis = 1,inplace=True)
print(train.shape)

# COMMAND ----------

numeric_columns = list(set(train.columns.tolist())-set(cat_features+ID+TARGET))
numerical = list(set(train.columns.tolist())-set(cat_features+ID+TARGET))
display(train[numeric_columns])

# COMMAND ----------

train = pd.DataFrame(train.reset_index(drop=True))
train.head()

# COMMAND ----------



plt.figure(figsize=(40, 100))
sns.set(font_scale= 1.2)
sns.set_style('ticks')

for i, feature in enumerate(cat_features):
    plt.subplot(10, 2, i+1)
    sns.countplot(data=train, x=feature, hue='TARGET', palette='rainbow')
    if feature:
        plt.title(feature)
        plt.xticks(rotation=90)
    
sns.despine()

# COMMAND ----------

plt.figure(figsize=(16, 7))
temp = train.copy()
sns.countplot(data=temp, x='ORGANIZATION_TYPE', hue='TARGET', palette='autumn')
plt.xticks(rotation=90)
plt.show()

# COMMAND ----------

plot_numerical = ['DAYS_BIRTH','AMT_CREDIT','AMT_INCOME_TOTAL','AMT_GOODS_PRICE','AMT_ANNUITY']
sns.pairplot(data=train,x_vars=plot_numerical,y_vars=plot_numerical, hue = 'TARGET', palette='Set2')

# COMMAND ----------

temp = train.copy()
temp[plot_numerical] = np.log(train[plot_numerical])
sns.pairplot(data=temp,x_vars=plot_numerical,y_vars=plot_numerical, hue = 'TARGET', palette='Set2')

# COMMAND ----------

for i in numerical:
  train[i]=train[i].fillna(-999)

# COMMAND ----------


label_encoder = LabelEncoder()
X_orig = train.copy()
X = np.zeros((len(train['CODE_GENDER']),1))
for i, name in enumerate(cat_features):
    x = label_encoder.fit_transform(train[name]).reshape(-1,1)
    X = np.hstack((X,x))

X = pd.DataFrame(X).drop([0],axis=1)
X.columns = cat_features

for i, name in enumerate(numerical):
    if name == 'AMT_INCOME_TOTAL':
        X = pd.concat([X,np.log(train[name])],axis=1)
    else:
        X = pd.concat([X,train[name]],axis=1)
data = pd.concat([X,train['TARGET']],axis=1)
Y = data.iloc[:,-1:]

# COMMAND ----------

sns.countplot(x = "TARGET",data = data)

# COMMAND ----------

indices=range(len(X))
X_train, X_test, y_train, y_test,indices_train,indices_test = train_test_split(X,Y,indices, test_size = 0.5, stratify=Y,
                                                    random_state=123)

# COMMAND ----------

print(X_train.shape)
print(X_test.shape)

# COMMAND ----------

X_test_raw = X_test.copy()

scaler = StandardScaler()
scaled_numfeats_train = pd.DataFrame(scaler.fit_transform(X_train[numerical]), 
                                     columns=numerical, index= X_train.index)
for col in numerical:
    X_train[col] = scaled_numfeats_train[col]
    
scaled_numfeats_test = pd.DataFrame(scaler.transform(X_test[numerical]),
                                    columns=numerical, index= X_test.index)

for col in numerical:
    X_test[col] = scaled_numfeats_test[col]