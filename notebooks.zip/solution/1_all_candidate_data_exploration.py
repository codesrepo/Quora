# Databricks notebook source
# MAGIC %md
# MAGIC <h2>Data Exploration Notebook - Veritas</h2>
# MAGIC 
# MAGIC 
# MAGIC <ol>
# MAGIC <li>CC lead prediction</li>
# MAGIC <li>Banking lead prediction </li>
# MAGIC <li>German credit risk</li>
# MAGIC <li>HC default risk</li>
# MAGIC <li>Synthetic loan data</li>
# MAGIC </ol>

# COMMAND ----------

# MAGIC %md
# MAGIC <h3>Import packages</h3>

# COMMAND ----------


from scipy.stats import chi2_contingency
from scipy.stats import pointbiserialr
import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC <h3>Define utility functions</h3>
# MAGIC <h5>Functions</h5>
# MAGIC 
# MAGIC <code>correlation_report(df,test_pairs,test_pairs_numeric)</code><br>
# MAGIC <code>&nbsp;df - Dataset having relevant columns</code><br>
# MAGIC <code>&nbsp;test_pairs - Categorical pairs for Chi-square test</code><br>
# MAGIC <code>&nbsp;test_pairs_numeric - Numeric pairs for point Biserial correlation</code>

# COMMAND ----------

def correlation_report(df,test_pairs,test_pairs_numeric,alpha=0.05):
  print("*************************Chisq-signicance test (Null hypothesis - Independence)*********************************")
  for v1,v2 in test_pairs:
    res="independent at %s significance"%(alpha)
    contigency= pd.crosstab(df[v1], df[v2]) 
    c, p, dof, expected = chi2_contingency(contigency)
    if p<alpha:
      res = "dependent at %s significance"%(alpha)
    print(v1,v2,p,"variables are %s"%(res))
  print("*************************Biserial correlation (ranges between -1 to +1)*********************************")
  for v1,v2 in test_pairs_numeric:
    pbc = pointbiserialr(df[v1], df[v2])
    print(v1,v2,pbc)
    
class color(object):
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'


# COMMAND ----------

# MAGIC %md
# MAGIC <h3>Read provided datasets</h3>

# COMMAND ----------


df_cc_lead_prediction = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/cc_lead_prediction.csv")
df_banking_lead_prediction = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/banking_lead_prediction.csv")
df_german_credit_risk = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/german_credit_data.csv")
df_hc_default_risk = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/hc_default_risk.csv")
df_loan_data = pd.read_csv("/dbfs/FileStore/shared_uploads/c56708a@ascendplatform.experian.com.sg/Loan_payments_data.csv")


# COMMAND ----------

# MAGIC %md
# MAGIC <h5>1. CC lead prediction<h5>

# COMMAND ----------

display(df_cc_lead_prediction)

# COMMAND ----------

df_cc_lead_prediction.groupby("Gender").agg({"Is_Lead":["mean","count"]})

# COMMAND ----------

df_cc_lead_prediction.groupby("Gender").agg({"Avg_Account_Balance":["mean","count"]})

# COMMAND ----------

df_cc_lead_prediction["elderly"] = df_cc_lead_prediction["Age"].apply(lambda x: 1 if x>65 else 0)
df_cc_lead_prediction["gender_tag"] = df_cc_lead_prediction["Gender"].apply(lambda x: 1 if x=="Male" else 0)
test_pairs = [('Gender','Is_Lead'),('elderly','Is_Lead'),('Occupation','Is_Lead'),('Occupation','Gender')]
test_pairs_numeric = [('Age','Is_Lead'),('Vintage','Is_Lead'),('Avg_Account_Balance','Is_Lead'),('Avg_Account_Balance','gender_tag')]  

correlation_report(df_cc_lead_prediction,test_pairs,test_pairs_numeric)

commentary = color.BOLD+"This data is slightly biased towards men. We need to demonstrate how our method can correct for Equality of opportunity without impacting the accuracy much."+color.END
print(commentary)

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>2. Banking lead prediction<h5>

# COMMAND ----------

display(df_banking_lead_prediction)

# COMMAND ----------

df_banking_lead_prediction["gender_tag"] = df_banking_lead_prediction["Gender"].apply(lambda x: 1 if x=="Male" else 0)

# COMMAND ----------

df_banking_lead_prediction.groupby("Gender").agg({"Approved":["mean","count"]})

# COMMAND ----------

df_banking_lead_prediction.groupby("Gender").agg({"Monthly_Income":["mean","count"]})

# COMMAND ----------


test_pairs = [('Gender','Approved'),('City_Category','Approved'),('Employer_Category1','Approved'),('Gender','Employer_Category1')]
test_pairs_numeric = [('Monthly_Income','Approved'),('Monthly_Income','gender_tag')] 
correlation_report(df_banking_lead_prediction,test_pairs,test_pairs_numeric)
commentary = color.BOLD+"It appears that this data is heavily biased towards men. We need to demonstrate how our method can correct for DI without impacting the accuracy much."+color.END
print(commentary)

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>3. German credit risk<h5>

# COMMAND ----------

display(df_german_credit_risk)

# COMMAND ----------

df_german_credit_risk["gender_tag"] = df_german_credit_risk["Sex"].apply(lambda x: 1 if x=="male" else 0)
df_german_credit_risk["risk_tag"] = df_german_credit_risk["Risk"].apply(lambda x: 1 if x=="good" else 0)
#df_german_credit_risk.groupby("Gender").agg({"Avg_Account_Balance":["mean","count"]})

# COMMAND ----------

df_german_credit_risk.groupby("Sex").agg({"risk_tag":["mean","count"]})

# COMMAND ----------

df_german_credit_risk.groupby("Sex").agg({"Credit amount":["mean","count"]})

# COMMAND ----------

#display(df_german_credit_risk)/ concept of weak and strong economic factors. Policy is that give loan if women has housing - but since women are equal earners this is a weak criteria as the positive prediction parity should be equal, we can solve for it by solving for Disparate Impact.

test_pairs = [('Sex','Risk'),('Housing','Risk'),('Job','Risk'),('Sex','Job'),('Sex','Housing')]
test_pairs_numeric = [('Credit amount','risk_tag'),('Credit amount','gender_tag')] 
correlation_report(df_german_credit_risk,test_pairs,test_pairs_numeric)

commentary = color.BOLD+"This data is slightly biased towards men. There is a correlation between credit amount and approval rate.  However, we see that risk is not related to job, we need to demonstrate how our method can correct for EA (shall correct for DI as well) without impacting the accuracy much. We can test for counterfactual correction ?"+color.END
print(commentary)

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>4. HC default risk<h5>

# COMMAND ----------

display(df_hc_default_risk)

# COMMAND ----------

df_hc_default_risk.groupby("CODE_GENDER").agg({"TARGET":["mean","count"]})

# COMMAND ----------

df_hc_default_risk.groupby("CODE_GENDER").agg({"AMT_INCOME_TOTAL":["mean","count"]})

# COMMAND ----------

df_hc_default_risk.groupby("TARGET").agg({"AMT_INCOME_TOTAL":"mean"})

# COMMAND ----------

df_hc_default_risk.groupby("NAME_FAMILY_STATUS").agg({"TARGET":["mean","count"]})

# COMMAND ----------

#If income is same the DI should directly be used - counterfactual fairness can be used ?

df_hc_default_risk['GENDER'] = df_hc_default_risk['CODE_GENDER'].apply(lambda x:1 if x=='F' else 0)
test_pairs = [('NAME_CONTRACT_TYPE','TARGET'),('FLAG_OWN_REALTY','TARGET'),('FLAG_OWN_CAR','TARGET'),('CODE_GENDER','FLAG_OWN_REALTY'),('CODE_GENDER','TARGET'),('NAME_INCOME_TYPE','TARGET'),('NAME_INCOME_TYPE','CODE_GENDER'),('NAME_EDUCATION_TYPE','CODE_GENDER'),('NAME_EDUCATION_TYPE','TARGET'),('NAME_FAMILY_STATUS','TARGET'),('NAME_FAMILY_STATUS','NAME_INCOME_TYPE'),('WEEKDAY_APPR_PROCESS_START','TARGET'),('CNT_CHILDREN','CODE_GENDER')]
test_pairs_numeric = [('AMT_INCOME_TOTAL','TARGET'),('AMT_INCOME_TOTAL','GENDER')] 
correlation_report(df_hc_default_risk,test_pairs,test_pairs_numeric)

commentary = color.BOLD+"We see that men have high default rate than women. Also outcome is independent of the income, this appears to be atypical case of historical prejudice where entry criteria for males is relaxed. We can adjust for counterfactual fairness and then test the Equality of opportunity/DI."+color.END
print(commentary)


# COMMAND ----------

# MAGIC %md
# MAGIC <h5>5. Synthetic loan data<h5>

# COMMAND ----------

df_loan_data["target"] = df_loan_data["past_due_days"].apply(lambda x: 1 if x>30 else 0)
display(df_loan_data)

# COMMAND ----------



# COMMAND ----------

df_loan_data.groupby("Gender").agg({"target":["mean","count"]})

# COMMAND ----------

test_pairs = [('Gender','target'),('education','Gender'),('education','target')] 
test_pairs_numeric = [('age','target'),('age','Gender')] 
correlation_report(df_loan_data,test_pairs,test_pairs_numeric)