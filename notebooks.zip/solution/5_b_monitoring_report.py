# Databricks notebook source
# MAGIC %md
# MAGIC <h2>Model development Notebook - Veritas</h2>
# MAGIC 
# MAGIC 
# MAGIC <ol>
# MAGIC <li>CC lead prediction</li>
# MAGIC <li>Banking lead prediction </li>
# MAGIC <li>German credit risk</li>
# MAGIC <li>HC default risk</li>
# MAGIC <li>Synthetic loan data</li>
# MAGIC </ol>

# COMMAND ----------

# MAGIC %md
# MAGIC <h3>Import packages</h3>

# COMMAND ----------

from sklearn.metrics import accuracy_score,roc_auc_score,confusion_matrix
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.preprocessing import LabelEncoder
from scipy.stats import chi2_contingency
from scipy.stats import pointbiserialr
import matplotlib.pyplot as plt
from sklearn.svm import SVC
import xgboost as xgb
import seaborn as sns
import pandas as pd
import numpy as np

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>Function definition</h5>

# COMMAND ----------

def get_bad_rate(df,target,score,threshold):
  bad_rate = 1-df[target][df[score]>=threshold].sum()/float(len(df[target][df[score]>=threshold]))
  acceptance_rate = (df[target][df[score]>=threshold].count()/float(len(df)))
  return("Bad rate = %s, Acceptance rate = %s, Gini=%s"%(bad_rate,acceptance_rate,2*roc_auc_score(df[target],df[score])-1))

def cost_benefit_analysis(df,target,score):
  total=[]
  goods = []
  bads = []
  thresh = []
  
  for i in range(0,100):
      try:
        threshold = i*0.01
        temp_total = df[target][df[score]>=threshold].count()
        temp_goods = df[target][df[score]>=threshold].sum()
        total.append(temp_total)
        goods.append(temp_goods)
        bads.append(temp_total-temp_goods)
        thresh.append(np.round(threshold,2))
      except:
        print(thresh)
  return pd.DataFrame({"threshold":thresh,"total":total,"goods":goods,"bads":bads})
        
def line_plot(df,xlabel,ylabel,title,x_list,y_list,x,y,vertical=None,save_path=None):
  plt.figure(figsize=(16, 7))
  sns.set(font_scale=1.8)
  sns.lineplot(x=x, y=y, hue='variable', linewidth = 4,
               data=pd.melt(df[y_list], x_list))
  
  if vertical!=None:
    plt.axvline(vertical, color='red',dashes=(2,2))
  
  plt.title(title)
  plt.xlabel(xlabel)
  plt.ylabel(ylabel)
  plt.grid()
  if save_path!=None:
    plt.savefig(save_path)
  plt.show()
   
   
  

# COMMAND ----------

class FairnessMaster(object):
  def __init__(self,df,target,prob,protected_var,privileged_group,base_threshold=1,n_bins=20):
    self.df = df
    self.target = target
    self.protected_var = protected_var
    self.privileged_group = privileged_group
    self.prob = prob
    self.base_threshold = base_threshold
    self.n_bins = n_bins
  
  
  def get_confusion_matrix(self,target,prediciton):
    tn, fp, fn, tp  = confusion_matrix(target, prediciton).ravel()
    return tn, fp, fn, tp
  
  def weird_division(self,n, d):
    return np.round(n / d,3) if d else 0
  
  def calculate_fairness_metrices(self):
    
    df_privileged = self.df[self.df[self.protected_var]==self.privileged_group]
    df_underprivileged = self.df[self.df[self.protected_var]!=self.privileged_group]
    prob=self.prob

    thresh_list = []
    dp_p = []
    eo_p = []
    pp_p = []
    di_tn_p = []

    dp_up = []
    eo_up = []
    pp_up = []
    di_tn_up = []
    
    absolute_equal_opportunity_difference = []
    equal_opportunity_difference = []
    average_abs_odds_difference = []
    average_odds_difference=[]
    statistical_parity_difference=[]
    
    #'absolute_equal_opportunity_difference'
    #equal_opportunity_difference
    
    
    #average_abs_odds_difference
    #average_odds_difference
    
    #statistical_parity_difference
    
    
    for i in range(0,100):
      try:
        thresh = i*0.01
        thresh_list.append(np.round(thresh,2))
        temp_p = df_privileged.copy()
        temp_up = df_underprivileged.copy()

        temp_p["prediction"] = temp_p[self.prob].apply(lambda x:1 if x>=thresh else 0 )
        temp_up["prediction"] = temp_up[self.prob].apply(lambda x:1 if x>=thresh else 0 )

        tn, fp, fn, tp = self.get_confusion_matrix(temp_p[self.target],temp_p["prediction"])
        dp_p.append(self.weird_division((fp+tp),(tn+ fp+ fn+ tp)))
        eo_p.append(self.weird_division((tp),( fn+ tp)))
        pp_p.append(self.weird_division(tp,fp+  tp))
        
        di_tn_p.append(self.weird_division((fp),( fp+ tn)))
        

        tn, fp, fn, tp = self.get_confusion_matrix(temp_up[self.target],temp_up["prediction"])
        dp_up.append(self.weird_division((fp+tp),(tn+ fp+ fn+ tp)))
        eo_up.append(self.weird_division((tp),( fn+ tp)))
        pp_up.append(self.weird_division(tp, fp+  tp))
        di_tn_up.append(self.weird_division((fp),( fp+ tn)))
      except:
        print(thresh)
        
    df = pd.DataFrame({"threshold":thresh_list,"di_p":dp_p,"eo_p":eo_p,"pp_p":pp_p,"di_up":dp_up,"eo_up":eo_up,"pp_up":pp_up,"di_tn_p":di_tn_p,"di_tn_up":di_tn_up})
    
    df["disparate_impact"] = df["di_up"]/df["di_p"]
    df["absolute_equal_opportunity_ratio"] = df["eo_up"]/df["eo_p"]
    df["pp_up_by_p"] = df["pp_up"]/df["pp_p"]  
    df["average_absolute_odds_ratio"] = ((df["eo_up"]+df["di_tn_up"])/(df["eo_p"]+df["di_tn_p"]))
    df["statistical_parity_ratio"] = df["di_up"]/df["di_p"]
    
    df["statistical_parity_difference"] = 1-(df["di_p"]-df["di_up"])
    df["equal_opportunity_difference"] = 1-(df["eo_p"]-df["eo_up"])
    
    df["absolute_equal_opportunity_difference"] =  1-abs(df["eo_p"]-df["eo_up"])
    df["average_odds_difference"] = 1-((((df["eo_p"]+df["di_tn_p"])-(df["eo_up"]+df["di_tn_up"]))*0.5))
    df["average_abs_odds_difference"] = 1-(abs(((df["eo_p"]+df["di_tn_p"])-(df["eo_up"]+df["di_tn_up"]))*0.5))
    

    return df 
  
 
  
  def calculate_harms_and_benefits(self,df_up):
    
      threshold_list = [np.round(self.base_threshold - i*0.01,2) for i in range(0,self.n_bins)]
      threshold_list = [i  for i in threshold_list if i>0]
      benefits = []
      harms = []
      temp_up = df_up.copy()
      temp_up["prediction"] = temp_up[self.prob].apply(lambda x:1 if x>=self.base_threshold else 0 )
      tn_base, fp_base, fn_base, tp_base = self.get_confusion_matrix(temp_up[self.target],temp_up["prediction"])
      
      for i in threshold_list:
        temp_up = df_up.copy()
        temp_up["prediction"] = temp_up[self.prob].apply(lambda x:1 if x>=i else 0 )
        tn, fp, fn, tp = self.get_confusion_matrix(temp_up[self.target],temp_up["prediction"])
        benefits.append(tp-tp_base)
        harms.append(fp-fp_base)
        
      df = pd.DataFrame({"threshold":threshold_list,"benefit":benefits,"harm":harms})
      return df  
    
  def apply_ROC(self,df,low_ROC_margin,high_ROC_margin,num_ROC_margin,metric_lb,metric_ub,metric_name):
      metric_val_old = -1
      df_privileged = self.df[self.df[self.protected_var]==self.privileged_group]
      df_underprivileged = self.df[self.df[self.protected_var]!=self.privileged_group]
      for ROC_margin in np.linspace(low_ROC_margin,high_ROC_margin, num_ROC_margin):     
        interval_low = self.base_threshold-ROC_margin
        interval_high = self.base_threshold+ROC_margin
        temp_p =df_privileged.copy()
        temp_up =df_underprivileged.copy()       
        temp_p["prediction"] = temp_p[self.prob].apply(lambda x:x if x>=interval_high or x<=interval_low else 0.01)
        temp_up["prediction"] = temp_up[self.prob].apply(lambda x:0.99 if x>=interval_low and x<=interval_high  else x ) 
        
        
        temp_p["prediction"] = temp_p["prediction"].apply(lambda x:1 if x>=self.base_threshold else 0 )
        temp_up["prediction"] = temp_up["prediction"].apply(lambda x:1 if x>=self.base_threshold else 0 )
        
        #print(temp_p["prediction"].sum(),temp_up["prediction"].sum(),"Prediction-SUM")

        tn, fp, fn, tp = self.get_confusion_matrix(temp_p[self.target],temp_p["prediction"])
        
        dp_p=(self.weird_division((fp+tp),(tn+ fp+ fn+ tp)))
        eo_p=(self.weird_division((tp),( fn+ tp)))
        pp_p=(self.weird_division(tp,fp+  tp))        
        di_tn_p=(self.weird_division((fp),( fp+ tn)))
        

        

        tn, fp, fn, tp = self.get_confusion_matrix(temp_up[self.target],temp_up["prediction"])
        dp_up=(self.weird_division((fp+tp),(tn+ fp+ fn+ tp)))
        eo_up=(self.weird_division((tp),( fn+ tp)))
        pp_up=(self.weird_division(tp, fp+  tp))
        di_tn_up=(self.weird_division((fp),( fp+ tn)))
        
        
        
        equal_opportunity_difference = 1-(eo_p-eo_up)    
        average_odds_difference = 1-((((eo_p+di_tn_p)-(eo_up+di_tn_up))*0.5))
        statistical_parity_difference = 1-(dp_p-dp_up)
        
        if metric_name=="equal_opportunity_difference":
            metric_val = equal_opportunity_difference
        elif metric_name=="average_odds_difference":
            metric_val = average_odds_difference
        elif metric_name=="statistical_parity_difference":
            metric_val = statistical_parity_difference
        else:
          raise ValueError("Please select correct metric (equal_opportunity_difference or average_odds_difference or statistical_parity_difference )")
        
        #print(ROC_margin,metric_val_old,metric_val,equal_opportunity_difference)
        
        if metric_val_old<metric_val:
          metric_val_old = metric_val
          
        if metric_val_old >=metric_lb:
          return ROC_margin,interval_low,interval_high
      raise ValueError("Please change the parameter range!!!!")
      
  def _get_corrected_value(self,x,interval_low,interval_high):
    #print(x[self.prob],interval_high)
    if x[self.protected_var]==self.privileged_group:
      if  x[self.prob]>=interval_high or x[self.prob]<=interval_low:
        return x[self.prob]
      else:
        return 0.01
      
    if x[self.protected_var]!=self.privileged_group:
      if  x[self.prob]>=interval_low and x[self.prob]<=interval_high:
        return 0.99
      else:
        return x[self.prob]
      
      
  def apply_ROC_correction(self,df,interval_low,interval_high):
    df["prediction_ROC"] = df.apply(lambda x:self._get_corrected_value(x,interval_low,interval_high),axis=1)
    return df
           
  

# COMMAND ----------

# MAGIC %md
# MAGIC <h5>Fairness analysis</h5>

# COMMAND ----------

df_chenxue = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/HC_test_pscore.csv")

df_chenxue["p_np_score_fix"] = 1- df_chenxue["p_np_score_fix"]
df_chenxue["TARGET"] = 1-df_chenxue["TARGET"]

df_chenxue["AGE"] = df_chenxue["DAYS_BIRTH"].apply(lambda x: 1 if x>1.5 else 0 )




new_obj = FairnessMaster(df_chenxue,"TARGET","p_np_score_fix","AGE",1,0.92,100)
df_metrices = new_obj.calculate_fairness_metrices()
display(df_metrices[["threshold","equal_opportunity_difference","average_abs_odds_difference","disparate_impact"]].sort_values("threshold",ascending=False))

# COMMAND ----------

import random
random.seed(2021)

new_obj = FairnessMaster(df_chenxue,"TARGET","p_np_score_fix","AGE",1,0.92,100)
df_metrices = new_obj.calculate_fairness_metrices()
#display(df_metrices[["threshold","equal_opportunity_difference","average_abs_odds_difference","disparate_impact"]].sort_values("threshold",ascending=False))
df_base = df_metrices[df_metrices.threshold==0.94]
df_base["month"] = 0
for i in range(1,12):
  df_new_applications = df_chenxue.sample(frac = 0.5, random_state=random.randint(0,100000))
  new_obj = FairnessMaster(df_new_applications,"TARGET","p_np_score_fix","AGE",1,0.92,100)
  df_metrices = new_obj.calculate_fairness_metrices()
  df_temp = df_metrices[df_metrices.threshold==0.94]
  df_temp["month"] = i
  df_base = pd.concat([df_base,df_temp])
#display(df_base[["month","disparate_impact"]])
df_base[["month","disparate_impact"]].to_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/DI_monitoring.csv",index=False)

# COMMAND ----------

import random
random.seed(2021)

new_obj = FairnessMaster(df_chenxue,"TARGET","p_np_score_fix","AGE",1,0.92,100)
df_metrices = new_obj.calculate_fairness_metrices()
#display(df_metrices[["threshold","equal_opportunity_difference","average_abs_odds_difference","disparate_impact"]].sort_values("threshold",ascending=False))
df_base = df_metrices[df_metrices.threshold==0.94]
df_base["month"] = 0
for i in range(1,12):
  df_new_applications = df_chenxue.sample(n = 1000, random_state=random.randint(0,100000))
  new_obj = FairnessMaster(df_new_applications,"TARGET","p_np_score_fix","AGE",1,0.92,100)
  df_metrices = new_obj.calculate_fairness_metrices()
  df_temp = df_metrices[df_metrices.threshold==0.94]
  df_temp["month"] = i
  df_base = pd.concat([df_base,df_temp])
display(df_base[["month","average_abs_odds_difference"]])
df_base[["month","average_abs_odds_difference"]].to_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/AOD_monitoring.csv",index=False)

# COMMAND ----------

display(df_base)

# COMMAND ----------

df_AOD = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/AOD_monitoring.csv")
df_AOD.columns = ["month","AOD_1000_random_approved_applications"]

df_DI = pd.read_csv("/dbfs/FileStore/shared_uploads/chenxue.li@experian.com/DI_monitoring.csv")
df_DI.columns = ["month","DI_all_new_approved_applications"]
df_DI["AOD_1000_random_approved_applications"] = df_AOD["AOD_1000_random_approved_applications"]

# COMMAND ----------

display(df_DI)

# COMMAND ----------

xxx

# COMMAND ----------

#df_DI.sort_values("month",inplace=True)
#df_DI["month"] = df_DI["month"].apply(lambda x:"M"+str(x))
line_plot(df_DI,'Month','Fairness values','Monitoring- DI and AOD for AGE',['month'],["month","AOD_1000_random_approved_applications","DI_all_new_approved_applications"],'month','value',vertical=None,save_path=None)